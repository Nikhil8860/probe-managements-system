#! /usr/bin/env python
'''
Apps video load test
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
Part of eProbe Netwok Testing by Etisalat UAE
'''

#Takes App name as an argument : 'facebook' , 'twitter' ...etc

import datetime
import eprobe
import sys

probeData = eprobe.read_cfg()
if not probeData == None:

    data_points=[]
    try:

        if not sys.argv[1] == "":

            PPPoEresult=sys.argv[1]
            PPPoEresult=PPPoEresult.split(',')

            payload={
                'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                'measurement' : 'PPPoE',
                'fields' : {
                    'PPPoETime':str(PPPoEresult[2]),
                    'Trials': str(PPPoEresult[0]),
                    'AcquiredIP': '"'+str(PPPoEresult[1])+'"'
                }
            }

            data_points.append(payload)

            if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [PPPoE] Test results successfully sent to server")
            else:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [PPPoE] ERROR sending Test results")

        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [PPPoE] No Result')

    except IndexError as err:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [PPPoE] Script Argument Error {}".format(err))
        sys.exit(1)

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [PPPoE] Error Reading probe.json')
