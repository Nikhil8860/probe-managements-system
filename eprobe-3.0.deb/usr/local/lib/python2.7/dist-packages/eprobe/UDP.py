#!/usr/bin/env python

'''
UDP throughput test
AuthorL ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
Part of eProbe Netwok Testing by Etisalat UAE
'''

import subprocess
import re
import datetime
import eprobe

probeData = eprobe.read_cfg()
if not probeData == None:

    #Perform iperf UDP test

    data_points=[]

    for server in probeData['udp_endpoints']:

        target_endpoint = str(server['networklevel']+"-"+server['endpoint'])

        process = subprocess.Popen(['timeout', '-k', '15s', '14s' , probeData['probe-config']['udp_iperf_path'] , '-u',
                                    '-c', server['ip'], '-p' , str(server['port']),
                                    '-d', '-b' , '10K' , '-l125' , '-n1250' ],
                stdout=subprocess.PIPE , stderr=subprocess.PIPE)
        out, err = process.communicate()

        results = []

        Jitter = re.findall(r'.*bits\/sec\s*(.*?)\s*ms\s*\d*\/\s*\d*\s*\(\d*\%\)$',str(out)) 
        if len(Jitter) != 0:
            results.append(Jitter[0])

        PL = re.findall(r'.*\s*\((.*?)\%\)$',str(out)) 
        if len(PL) != 0:
            results.append(PL[0])

        if len(results) != 0:

            payload={
                'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                'measurement' : 'UDP',
                'tags' : {
                    'Endpoint': str(target_endpoint)
                    } ,
                'fields' : {
                    'Jitter':str(results[0]) ,
                    'PacketLoss':str(results[1])
                }
            }

            data_points.append(payload)

        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [UDP] No Result: '+target_endpoint)

    if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [UDP] Test results successfully sent to server")
    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [UDP] ERROR sending Test results")

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [UDP] Error Reading probe.json')
