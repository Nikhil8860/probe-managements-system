#!/usr/bin/python

'''
DNS test on list of URLs for different DNS servers
Part of eProbe Netwok Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''

import subprocess
import datetime
import re
import eprobe
import json

probeData = eprobe.read_cfg()
if not probeData == None:
    #Perform DNS Tests

    data_points=[]

    for dns_server in probeData['probe-config']['DNS-Servers']:

        for url in probeData['probe-config']['DNS-urls']:
            DNS=None

            #Start DNS test on URL
            process = subprocess.Popen(['timeout', '-k', '5s', '2s' , 'dig', '@'+dns_server , url], stdout=subprocess.PIPE , stderr=subprocess.PIPE)
            out, err = process.communicate()

            validURL = re.findall(r'status: NOERROR',str(out))

            if not len(validURL) == 0:
                found = re.findall(r'SERVER\:\s*(.*?)\#\D*',str(out))
                if not len(found) == 0:
                    DNSServer = found[0]
                    #DNS Server info exists

                found = re.findall(r'Query\s*time:\s*(.*?)\s*msec',str(out))
                if not len(found) == 0 :
                    DNS = found[0]
                    #DNS result exists

            #if test is successful
            if DNS:

                payload={
                    'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                    'measurement' : 'DNS',
                    'tags' : {
                        'DNSServer': str(DNSServer) ,
                        'URL' :str(url)
                        } ,
                    'fields' : {
                        'DNS':str(DNS)
                    }
                }

                data_points.append(payload)

            else:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [DNS] No Result for  '+url+' @'+dns_server)

    if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [DNS] Test results successfully sent to server")
    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [DNS] ERROR sending Test results")

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [DNS] Error Reading probe.cfg')
