#!/usr/bin/env python

'''
Checkin at server 
Part of eProbe Netwok Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''

#Takes probe IP address and eprobe version number as arguments: PPP IP address , eprobeVer
#additionally, takes probeID as argument when checking-in upon installation

import datetime
import time
import eprobe
import sys
import requests
import os
import json

def validate_ip(s):
        a = s.split('.')
        if len(a) != 4:
                return False
        for x in a:
                if not x.isdigit():
                        return False
                i = int(x)
                if i < 0 or i > 255:
                        return False
        return True

def do_checkin(ip,eprobeVer,probeID):

    secrets=eprobe.read_secrets()
    if not secrets == None:

        check_in_datetime= str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        payload={'probeID': probeID , 'IP' : ip , 'LastSeen' : check_in_datetime , 'eprobeVer' : eprobeVer }

        #Start check in process 
        try:
            r= requests.post('https://eprobe-measurement-server-1:8083/check-in',
                auth= requests.auth.HTTPBasicAuth('probe', secrets['probepass']),
                headers= {'Content-Type': 'application/json'},
                data= json.dumps(payload),
                verify= False,
                timeout= 30)

            if r.status_code == 200 and r.json()['Checkin'] == 'Successful':
                try:
                    jsondata=r.json()
                    jsondata.pop('Checkin',None)

                    if jsondata['update-config']['update_available'] == "True":
                        eprobe.download_test_files(jsondata)

                    jsondata.pop('update_available',None)

                    if jsondata:
                        with open('/etc/eprobe/probe.json', 'w') as outfile:
                            json.dump(jsondata, outfile)

                except EnvironmentError:
                    print('Error Writing file: /etc/eprobe/probe.json EnvironmentError '+str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    sys.exit(1)

                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Check-in] Check in successful")
                sys.exit(0)

            else:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Check-in] Check-in request failure:  '+r.text)
                sys.exit(1)

        except requests.exceptions.RequestException as e:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Check-in] RequestsError '+str(e))
            sys.exit(1)

    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Check-in] Error Reading secrets')
        sys.exit(1)

try:
    check_in_datetime= str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    if len(sys.argv) > 1:

        if validate_ip(sys.argv[1]):
            ip=sys.argv[1]
        else:
            print("[Check-in] Check-in IP Address error: "+check_in_datetime)
            sys.exit(1)

        eprobeVer=sys.argv[2]

        if len(sys.argv) == 4:
            '''initial checkin at installation time'''
            probeID=sys.argv[3]
            if(ip and eprobeVer and probeID):
                do_checkin(ip,eprobeVer,probeID)

        else:
            '''usual checkin'''
            probeData = eprobe.read_cfg()
            if not probeData == None:

                probeID=probeData['probeID']

                if ip and eprobeVer and probeID:
                    do_checkin(ip,eprobeVer,probeID)
            else:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Check-in] Error Reading probe.json')
                sys.exit(1)

    else:
        print("[Check-in] script arguments missing: "+check_in_datetime)
        sys.exit(1)

except IndexError as err:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Check-in] script arguments error {}".format(err))
    sys.exit(1)