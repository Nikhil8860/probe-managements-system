#!/usr/bin/env python

'''
TCP throughput test
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
Part of eProbe Netwok Testing by Etisalat UAE
'''

import subprocess
import re
import json
import datetime
import time
import eprobe


def iperf2_test(target_endpoint,server,probeData):
    '''Runs TCP test using iperf2'''
    
    iperf2_cmd = ['timeout', '-k', '15s', '14s',
        probeData['probe-config']['tcp_iperf_path'],
        '-c', server['ip'],
        '-d',
        '-p', str(server['port']),
        '-f','m'
        ]

    process = subprocess.Popen(iperf2_cmd,
            stdout=subprocess.PIPE , stderr=subprocess.PIPE)

    out, err = process.communicate()    
    results = []

    foundTX = re.findall(r'\].*MBytes\s*(.*?)\s*Mbits\/sec\s*\n\[',str(out)) 
    if len(foundTX) != 0:
        results.append(foundTX[0])

    foundRX = re.findall(r'\].*MBytes\s*(.*?)\s*Mbits\/sec$',str(out)) 
    if len(foundRX) != 0:
        results.append(foundRX[0])

    #Strip trailing and leading white spaces
    out=out.strip()
    #Reorder results if out of order
    results = eprobe.reorder(out, results)

    if len(results) != 0:

        payload={
            'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
            'measurement' : 'TCP',
            'tags' : {
                'Endpoint': target_endpoint
                } ,
            'fields' : {
                'DownloadThrpt':str(results[0]) ,
                'UploadThrpt':str(results[1])
            }
        }

        data_points.append(payload)
    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [TCP] No Result: '+target_endpoint)


def iperf3_test(target_endpoint,server,probeData):
    '''Runs TCP test using iperf2'''

    download_command = ['timeout', '-k', '15s', '14s' , probeData['probe-config']['tcp_iperf_path'],
     '-c',  server['ip'] , '-R' , '-p' , str(server['port']) , '-P3', '-J', '-O1']

    upload_command = ['timeout', '-k', '15s', '14s' , probeData['probe-config']['tcp_iperf_path'],
     '-c',  server['ip'] , '-p' , str(server['port']) ,'-P3', '-J' , '-O1']

    payload={
        'measurement' : 'TCP',
        'tags' : {
            'Endpoint': target_endpoint

            } ,
        'fields' : {}
    }

    #Start Download test
    try:
        dl_trials = 0
        process = subprocess.Popen(download_command,
                stdout=subprocess.PIPE , stderr=subprocess.PIPE)

        dl_output, err = process.communicate()
        dl_output = json.loads(dl_output)

        while 'error' in dl_output.keys() and dl_trials < 30:
            time.sleep(5)
            process = subprocess.Popen(download_command,
                    stdout=subprocess.PIPE , stderr=subprocess.PIPE)

            dl_output, err = process.communicate()
            dl_output = json.loads(dl_output)
            dl_trials += 1

        sum_received = dl_output['end']['sum_received']['bits_per_second']

        if sum_received is not None and sum_received >= 1:
            payload['fields'].update({'DownloadThrpt': str(round(sum_received/1000000,2))})
            payload.update({'timestamp':str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))})

    except (ValueError, KeyError) as e:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [TCP] [download] JSON output failure: "+str(e)+": "+target_endpoint)
        return
    try:

        #Start Upload test

        ul_trials = 0
        process = subprocess.Popen(upload_command,
                stdout=subprocess.PIPE , stderr=subprocess.PIPE)

        ul_output, err = process.communicate()
        ul_output = json.loads(ul_output)

        while 'error' in ul_output.keys() and ul_trials < 30:
            time.sleep(5)
            process = subprocess.Popen(upload_command,
                stdout=subprocess.PIPE , stderr=subprocess.PIPE)

            ul_output, err = process.communicate()
            ul_output = json.loads(ul_output)
            ul_trials += 1

        sum_sent = ul_output['end']['sum_sent']['bits_per_second']

        if sum_sent is not None and sum_sent >= 1:
            payload['fields'].update({'UploadThrpt': str(round(sum_sent/1000000,2))})
            if 'timestamp' not in payload.keys():
                payload.update({'timestamp':str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))})

    except (ValueError, KeyError) as e:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [TCP] [upload] JSON output failure: "+str(e)+" : "+target_endpoint)
        return

    if any(value in payload['fields'].keys() for value in ['DownloadThrpt','UploadThrpt']):
        data_points.append(payload)

    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [TCP] No Result: '+target_endpoint)


data_points=[]
probeData = eprobe.read_cfg()
if not probeData == None:
        
        for server in probeData['tcp_endpoints']:

            target_endpoint = str(server['networklevel']+"-"+server['endpoint'])

            if 'TRA' in probeData['TOS']:
                iperf3_test(target_endpoint,server,probeData)
            else:
                iperf2_test(target_endpoint,server,probeData)

        if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [TCP] Test results successfully sent to server")
        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [TCP] ERROR sending Test results")

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [TCP] Error Reading probe.json')
