#!/usr/bin/env python

'''
URLs HTTP response time test
Part of eProbe Netwok Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''

import requests
import datetime
import eprobe

#Silencing SSL certificate verification warnings
requests.packages.urllib3.disable_warnings()

probeData = eprobe.read_cfg()
if not probeData == None:

    data_points=[]
    sites=probeData['probe-config']['HTTP-urls']
    results = {}
    for i in range(0,len(sites)):
        try:
            r = requests.get(sites[i] , timeout=10, verify=False)
            #is response 200 OK ? , trying 5 times otherwise
            trials =0
            while( (not r.status_code == 200) and trials <5 ):
                r = requests.get(sites[i], timeout=10, verify=False)
                trials+=1

                #save measurement in results dictionary 
            if r.status_code == 200:
                results[sites[i]] = (r.elapsed.total_seconds(), str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) )
                        # key holds website, value holdes a tuple: value[0] and value[1]
                        # value[0] = measurement , value[1]= time of measurement=current time    
            else:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [HTTP] No Result for '+sites[i])

        except requests.exceptions.RequestException as e:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [HTTP] Requests Error '+sites[i]+' '+str(e))    

    #if any result is saved at all      
    if len(results) != 0 :
        for key, value in results.items():

            payload={
                'timestamp': str(value[1]),
                'measurement' : 'HTTP-resp',
                'tags' : {
                    'URL': str(key) 
                    } ,
                'fields' : {
                    'value':str(value[0])
                }
            }

            data_points.append(payload)

        if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [HTTP] Test results successfully sent to server")
        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [HTTP] ERROR sending Test results")

    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [HTTP] No HTTP Result for any URL')

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [HTTP] Error Reading probe.json')
