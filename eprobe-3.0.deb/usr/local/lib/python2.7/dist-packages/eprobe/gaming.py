#!/usr/bin/python

'''
Gaming traceroute and latency  test
Part of eProbe Netwok Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''

import subprocess
import datetime
import re
import eprobe
import sys
import requests
import json

#Silencing SSL certificate verification warnings
requests.packages.urllib3.disable_warnings()

def validate_ip(s):
        a = s.split('.')
        if len(a) != 4:
                return False
        for x in a:
                if not x.isdigit():
                        return False
                i = int(x)
                if i < 0 or i > 255:
                        return False
        return True

def traceroute(probeData):
    #traceroute test

    ip_addr=requests.get("https://217.165.208.115:8083/myip", verify = False , timeout=30)
    trials=0
    while(not ip_addr.status_code == 200 and trials < 5):
        ip_addr=requests.get("https://217.165.208.115:8083/myip", verify = False , timeout=30)
        trials+=1

    if not validate_ip(ip_addr.text):
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Gaming] Invalid source IP Address')
        sys.exit(1)
    else:

        #Perform traceroute Test
        payload = {
            "OLT":probeData['GID'],
            "test_type":"gaming",
            "traceroutes" : []
        }

        for game, game_info in probeData['gaming'].iteritems():
             for server in game_info['servers']:

                p = subprocess.Popen(['timeout', '-k', '11s', '10s' , 'traceroute', '-w' , '2', '-q' , '1' , str(server['IP'])],
                                    stdout = subprocess.PIPE,
                                    stderr = subprocess.PIPE)
                out, err = p.communicate()

                if "Cannot" not in out and "Cannot" not in err:

                    payload['traceroutes'].append({
                        "src":str(ip_addr.text),
                        "dst": game.encode('utf-8')+" - "+str(server['location']+" Server"),
                        "datetime":str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                        "traceroute":out
                        })
                else:
                    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [Gaming-traceroute] No Result: '+game.encode("utf-8")+" - "+str(server['location'])+" - "+str(server['IP']))

        if len(payload['traceroutes']) != 0:

            try:

                r= requests.post('https://eprobe-measurement-server-1:8083/traceroute',
                headers={'Content-Type': 'application/json'}, data=json.dumps(payload), verify= False , timeout=30)

                trials=0
                while (trials < 5 and not r.status_code == 200):
                    r= requests.post('https://eprobe-measurement-server-1:8083/traceroute',
                    headers={'Content-Type': 'application/json'}, data=json.dumps(payload), verify= False , timeout=30)
                    trials+=1

                if r.status_code == 200 and r.json()['traceroute_received'] == 'Successful':
                    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Gaming-traceroute] Data write successful")
                else:
                    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Gaming-traceroute] Data write unsuccessful")

            except requests.exceptions.RequestException as e:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Gaming-traceroute] Requests Error '+str(e))

        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [Gaming-traceroute] No results')

def latency(probeData):
    #perform latency test

    data_points=[]

    for game, game_info in probeData['gaming'].iteritems():
        for server in game_info['servers']:

            RTTresults = []

            #Start RTT test
            p = subprocess.Popen(['timeout', '-k', '6s', '5s' , 'ping', '-c', '3', server['IP']], stdout = subprocess.PIPE, stderr = subprocess.PIPE)
            out, err = p.communicate()

            minREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*(.*?)/')
            avgREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/(.*?)/')
            maxREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/\d*\.\d*/(.*?)/')
            mdevREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/\d*\.\d*/\d*\.\d*/(.*?)\s*ms')

            #min
            found = minREGEX.findall(str(out))
            if not len(found) == 0:
                RTTresults.append(str(found[0]))

            #avg
            found = avgREGEX.findall(str(out))
            if not len(found) == 0:
                RTTresults.append(str(found[0]))

            #max
            found = maxREGEX.findall(str(out))
            if not len(found) == 0:
                RTTresults.append(str(found[0]))

            #if test is successfully
            if RTTresults and len(RTTresults) != 0:

                payload={
                    'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                    'measurement' : 'RTT-gaming',
                    'tags' : {
                        'game' :game.replace(' ','\ ').encode("utf-8"),
                        'server_location':server['location'].replace(' ','\ '),
                        'IP':server['IP']
                            } ,
                    'fields' : {
                        'RTTavg':str(RTTresults[1]),
                        'RTTmin':str(RTTresults[0]),
                        'RTTmax':str(RTTresults[2])
                        }
                }

                data_points.append(payload)

            else:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [Gaming-ping] No Result for '+game.encode("utf-8")+" - "+str(server['location'])+" - "+str(server['IP']))

    if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Gaming-ping] Test results successfully sent to server")
    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Gaming-ping] ERROR sending Test results")

probeData = eprobe.read_cfg()
if not probeData == None:

    try:
        if sys.argv[1] == "traceroute":
            traceroute(probeData)
        elif sys.argv[1] == "latency":
            latency(probeData)
        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Gaming] Invalid Argument Name')
            sys.exit(1)
    except IndexError as err:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Gaming] Argument Error {}".format(err))
        sys.exit(1)

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Gaming] Error Reading probe.cfg')
