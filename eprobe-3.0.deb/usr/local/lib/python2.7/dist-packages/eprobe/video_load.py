#! /usr/bin/env python
'''
Apps video load test
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
Part of eProbe Netwok Testing by Etisalat UAE
'''

#Takes App name as an argument : 'facebook' , 'twitter' ...etc

from __future__ import unicode_literals
import youtube_dl
import datetime
import eprobe
import sys

class MyLogger(object):
    def debug(self, msg):
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
            print(msg)

def hook(d):
    if d['status'] == 'finished':
        global video_load_time , throughput
        video_load_time = d['elapsed']
        throughput = d['downloaded_bytes']*8/d['elapsed']

probeData = eprobe.read_cfg()
if not probeData == None:

    data_points=[]
    video_load_time,throughput,url = None, None , None
    ydl_opts = {
        'quiet':True,
        'format': 'best',
        'keepvideo': None,
        'logger': MyLogger(),
        'progress_hooks': [hook]
    }
    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        try:
            info = ydl.extract_info(probeData['apps-video'][sys.argv[1]], download=True )
            url = info['formats'][-1]['url']
        except youtube_dl.utils.DownloadError as err:
            print "DownloadError: ",err
        except (IndexError,KeyError) as err:
            print "Error fetching format url: ",err
        except IndexError as err:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [video-"+sys.argv[1]+"] Script Argument Error {}".format(err))
            sys.exit(1)

    if video_load_time and throughput and url:

        payload={
            'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
            'measurement' : sys.argv[1],
            'fields' : {
                'videoload_time':str(video_load_time),
                'video_throughput': str(throughput),
                'video_url': str('"'+url+'"')
            }
        }

        data_points.append(payload)

        if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [video-"+sys.argv[1]+"] Test results successfully sent to server")
        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [video-"+sys.argv[1]+"] ERROR sending Test results")

    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [video-'+sys.argv[1]+'] No Result')

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [video-'+sys.argv[1]+'] Error Reading probe.cfg')
