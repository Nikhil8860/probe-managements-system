#!/usr/bin/python

'''
URLs latency RTT (Round Trip Time) test
Part of eProbe Netwok Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''

import subprocess
import datetime
import re
import eprobe

probeData = eprobe.read_cfg()
if not probeData == None:

    #Perform RTT Test

    data_points=[]
    for url in probeData['probe-config']['RTT-urls']:
        RTTresults = []

        #Start RTT test
        p = subprocess.Popen(['timeout', '-k', '6s', '5s' , 'ping', '-c', '3', url], stdout = subprocess.PIPE, stderr = subprocess.PIPE)
        out, err = p.communicate()

        minREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*(.*?)/')
        avgREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/(.*?)/')
        maxREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/\d*\.\d*/(.*?)/')
        mdevREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/\d*\.\d*/\d*\.\d*/(.*?)\s*ms')

        #min
        found = minREGEX.findall(str(out))
        if not len(found) == 0:
            RTTresults.append(str(found[0]))

        #avg
        found = avgREGEX.findall(str(out))
        if not len(found) == 0:
            RTTresults.append(str(found[0]))

        #max
        found = maxREGEX.findall(str(out))
        if not len(found) == 0:
            RTTresults.append(str(found[0]))

        #if test is successfully
        if RTTresults and len(RTTresults) != 0:

            payload={
                'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                'measurement': 'RTT-urls',
                'tags': {
                    'URL': str(url)
                        } ,
                'fields': {
                    'RTTavg': str(RTTresults[1]),
                    'RTTmin': str(RTTresults[0]),
                    'RTTmax': str(RTTresults[2])
                    }
            }

            data_points.append(payload)

        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [RTT-urls] No Result for '+url)

    if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [RTT-urls] Test results successfully sent to server")
    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [RTT-urls] ERROR sending Test results")

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [RTT-urls] Error Reading probe.json')
