#!/usr/bin/env python

'''
ISG/EMIX RTT latency test
Part of eProbe Netwok Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''
#Takes Endpoint as an argument : 'EMIX-FJN' , 'EMIX-SKM' or 'ISG'

import subprocess
import re
import datetime
import eprobe

probeData = eprobe.read_cfg()
if not probeData == None:

    #Perform latency test towards udp_endpoints

    data_points=[]

    if not 'TRA' in probeData['TOS']:
        ping_targets = probeData['tcp_endpoints']
    else:
        ping_targets = probeData['udp_endpoints']

    if probeData['NetLayer'] != 'OLT':
        ping_targets = probeData['udp_endpoints']

    for endpoint in ping_targets:
    	target_endpoint = str(endpoint['networklevel']+"-"+endpoint['endpoint'])

        p = subprocess.Popen(['timeout', '-k', '6s', '5s' , 'ping', '-c', '3', '-W' , '2' , endpoint['ip'] ], stdout = subprocess.PIPE, stderr = subprocess.PIPE)
        out, err = p.communicate()

        RTTresults =[]
        minREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*(.*?)/')
        avgREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/(.*?)/')
        maxREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/\d*\.\d*/(.*?)/')
        mdevREGEX = re.compile(r'.*min/avg/max/mdev\s*\=\s*\d*\.\d*/\d*\.\d*/\d*\.\d*/(.*?)\s*ms')

        #min
        found = minREGEX.findall(str(out))
        if not len(found) == 0:
            RTTresults.append(str(found[0]))

        #avg
        found = avgREGEX.findall(str(out))
        if not len(found) == 0:
            RTTresults.append(str(found[0]))

        #max
        found = maxREGEX.findall(str(out))
        if not len(found) == 0:
            RTTresults.append(str(found[0]))

        if len(RTTresults) != 0:

            payload={
                'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                'measurement' : 'RTT',
                'tags' : {
                    'Endpoint': target_endpoint
                    } ,
                'fields' : {
                    'RTTavg':str(RTTresults[1]),
                    'RTTmax':str(RTTresults[2]),
                    'RTTmin':str(RTTresults[0])
                }
            }

            data_points.append(payload)

        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [RTT] test run. No RTT result: '+str(target_endpoint))

    if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [RTT] Test results successfully sent to server")
    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [RTT] ERROR sending Test results")

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [RTT] Error Reading probe.json')
