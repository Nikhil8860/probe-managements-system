#!/usr/bin/env python



'''
Traceroute test
Part of eProbe Netwok Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''
#Takes src IP as an argument and pulls target domain from configuration file


import subprocess
import re
import sys
import datetime
import eprobe
import requests
import json



def validate_ip(s):
        a = s.split('.')
        if len(a) != 4:
                return False
        for x in a:
                if not x.isdigit():
                        return False
                i = int(x)
                if i < 0 or i > 255:
                        return False
        return True



probeData = eprobe.read_cfg()
if not probeData == None:


    try:

        if not validate_ip(sys.argv[1]):
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Traceroutes] Invalid IP Address')
            sys.exit(1)
        else:

            #Perform traceroute test

            payload = {
                    "OLT":probeData['GID'],
                    "traceroutes" : [],
                    "test_type":"non-gaming"
            }

            endpoints=probeData['tcp_endpoints']
            if probeData['NetLayer'] != 'OLT':
                endpoints=probeData['udp_endpoints']
            
            destinations = endpoints+probeData['probe-config']['traceroute_urls']

            for dst in destinations:

                if isinstance(dst,dict):
                    target = dst['ip']
                    target_name = dst['endpoint']+"-"+dst['networklevel']+"-"+dst['networkelement']
                else:
                    target=dst
                    target_name=dst

                p = subprocess.Popen(['timeout', '-k', '11s', '10s' , 'traceroute', '-w', '2', '-q', '1' , str(target)],
                                    stdout = subprocess.PIPE,
                                    stderr = subprocess.PIPE)
                out, err = p.communicate()

                if "Cannot" not in out and "Cannot" not in err:
                    

                    payload['traceroutes'].append({
                        "src": probeData['GID']+" ("+str(sys.argv[1])+")",
                        "dst":target_name,
                        "datetime":str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                        "traceroute":out
                        })
                else:
                    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [Traceroute] No result: '+str(target_name))

            if len(payload['traceroutes']) != 0:

                try:
                 
                    r= requests.post('https://eprobe-measurement-server-1:8083/traceroute',
                    headers={'Content-Type': 'application/json'}, data=json.dumps(payload), verify= False , timeout=30)
                    

                    trials=0
                    while (trials < 5 and not r.status_code == 200):
                        r= requests.post('https://eprobe-measurement-server-1:8083/traceroute',
                        headers={'Content-Type': 'application/json'}, data=json.dumps(payload), verify= False , timeout=30)
                        trials+=1


                    if r.status_code == 200 and r.json()['traceroute_received'] == 'Successful':
                        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Traceroutes] Data write successful")
                    else:
                        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Traceroutes] Data write unsuccessful")

                except requests.exceptions.RequestException as e:
                    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Traceroutes] Requests Error '+str(e))

            else:
                print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [Traceroutes] No results')

    except IndexError as err:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Traceroutes] Script Argument Error {}".format(err))
        sys.exit(1)

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [Traceroutes] Error Reading probe.json')
             
