#! /usr/bin/env python
'''
Apps photo load test
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
Part of eProbe Netwok Testing by Etisalat UAE
'''

#Takes App name as an argument : 'facebook' , 'twitter' or 'instagram'

from bs4 import BeautifulSoup
import requests
import datetime
import eprobe
import sys

#Silencing SSL certificate verification warnings
requests.packages.urllib3.disable_warnings()

probeData = eprobe.read_cfg()
if not probeData == None:

    data_points=[]

    photo_load_time,throughput,photo_url = None, None , None
    try:

        IMAGE_BASE_URL=probeData['apps-photo'][sys.argv[1]]
        headers={'user-agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}

        image_html = requests.get(IMAGE_BASE_URL, headers=headers, timeout=10)
        if image_html.status_code == 200:
            soup = BeautifulSoup(image_html.text, 'html.parser')
            photo_url = soup.find("meta", property="og:image")['content']
            load_photo= requests.get(photo_url, headers=headers, timeout=10)
            if load_photo.status_code == 200:
                photo_load_time = load_photo.elapsed.total_seconds()
                throughput=float(load_photo.headers['Content-Length'])*8/photo_load_time
        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [photo-'+sys.argv[1]+'] Error Loading IMAGE_BASE_URL')

    except IndexError as err:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [photo-X] Script Argument Error {}".format(err))
        sys.exit(1)

    except requests.exceptions.RequestException as e:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [photo-'+sys.argv[1]+'] Requests Error '+str(e))

    if photo_load_time and throughput and photo_url:

        payload={
            'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
            'measurement' : sys.argv[1],
            'fields' : {
                'photoload_time':str(photo_load_time),
                'photoload_throughput': str(throughput),
                'photo_url': str('"'+photo_url+'"')
            }
        }

        data_points.append(payload)

        if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [photo-"+sys.argv[1]+"] Test results successfully sent to server")
        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [photo-"+sys.argv[1]+"] ERROR sending Test results")

    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [photo-'+sys.argv[1]+'] No Result')

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [photo-'+sys.argv[1]+'] Error Reading probe.json')
