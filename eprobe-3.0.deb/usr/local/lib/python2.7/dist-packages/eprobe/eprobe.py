#!/usr/bin/env python
'''
eProbe main module
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
Part of eProbe Netwok Testing by Etisalat UAE
'''

import datetime
import base64
import requests
import time
import string
import json
import os

#Silencing SSL certificate verification warnings
requests.packages.urllib3.disable_warnings()

def download_test_files(probeData):
    '''Download and install latest tesing files. Overwrites existing files'''
    for file in probeData['update-config']['update_files']:
        FILE_PATH = file['path']+file['file_name']
        try:
            with requests.get("https://eprobe-measurement-server-1:8083/update/"+file['file_name'],
                auth = requests.auth.HTTPBasicAuth('updater',base64.b64decode(probeData['update-config']['updater_key'])),
                stream=True,
                verify=False,
                timeout=5) as request:
                with open(FILE_PATH, 'wb') as f:
                    for chunk in request.iter_content(chunk_size = 1024):
                        f.write(chunk)

            os.chmod(FILE_PATH, int(file['permissions'], base=8))
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Check-in] Update Successful for: "+str(FILE_PATH))

        except (OSError, EnvironmentError, requests.exceptions.RequestException) as e:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [Check-in] Error updating test file: "+str(FILE_PATH), e)

def read_cfg():
    '''Function to read config file probe.json'''

    try:
        with open('/etc/eprobe/probe.json') as json_data_file:
            probeData = json.load(json_data_file)

        return probeData

    except EnvironmentError:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" Error reading file /etc/eprobe/probe.json, EnvironmentError: " , EnvironmentError)
        return None

def read_secrets():
    '''Function to read secrets'''

    try:
        probe=""
        shadows = open ("/etc/eprobeshadows",'r')
        for line in shadows.readlines():
            line = line.replace("\n","").split(":")
            if line[0] == "probe":
                probe=base64.b64decode(line[1])

        passes = {
        'probepass': probe
        }
        return passes
    except IOError:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" Can't open secrets file ")
        return None

def add_common_tags(probeData):
    '''Function to populate common tags'''

    new_tags = {
    "probeID": str(probeData['probeID']), 
    "TOS": probeData['TOS'],
    "Region": probeData['Region'],
    "ISG": "ISG-"+probeData['ISG'],
    "SiteName": probeData['SiteName'].replace(' ','\ '),
    "Source": str(probeData['GID']),
    "APE": str(probeData['APE']),
    "ShortCode": str(probeData['ShortCode']),
    "Speed": str(probeData['Speed']),
    "NetLayer": str(probeData['NetLayer'])
    } 

    return new_tags

def send_results_to_api(data_points,probeData):
    '''Function to send test results to server via API''' 

    try:

        for data_point in data_points:
            common_tags = add_common_tags(probeData)
            if 'tags' not in data_point:
                data_point['tags'] = common_tags
            else:
                data_point['tags'].update(add_common_tags(probeData))

        data= {'influx_retention_policy': probeData['probe-config']['influxdb_retention_policy'], 'data_points': data_points }
        url = "https://eprobe-measurement-server-1:8083/write-results"

        r=requests.post(url=url,
            headers={'Content-Type': 'application/json'},
            auth = requests.auth.HTTPBasicAuth('data_writer',base64.b64decode(probeData['probe-config']['data_writer'])),
            data = json.dumps(data),
            verify = False,
            timeout=30)

        trials=0

        while (trials < 5 and not r.status_code == 200):
            r=requests.post(url=url,
                auth = requests.auth.HTTPBasicAuth('data_writer',base64.b64decode(probeData['probe-config']['data_writer'])),
                data = data_points,
                verify = False,
                timeout=30)

            trials+=1

        if r.status_code == 200 and r.json()['data_written'] == 'successfully':
            return True
        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' '+r.text)
            return False

    except requests.exceptions.RequestException as e:
        print('[eprobe.py] '+str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' ERROR sending results to API '+str(e))
        return False

def trim(str):
    '''Function to trim iperf output lines'''
    return str[0:5]

def reorder(output,Results):
    '''Function to reorder iperf Results in case upload arrived before download in report'''    
    lines=string.split(output, '\n')
    if len(lines) >= 5:
            lines=lines[-5:]
            lines = [trim(s) for s in lines]

    if len(Results) > 1:
            if lines[0] != lines[-1]:
                    Results[0], Results[1] = Results[1], Results[0]
    else:
            Results=[]

    return Results
