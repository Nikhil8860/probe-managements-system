#!/usr/bin/env python

'''
HPING3 latency test using TCP
Part of eProbe Network Testing by Etisalat UAE
Author: ALI MOHAMDI <amohamdi@etisalat.ae>
Maintainer: ALI MOHAMDI <amohamdi@etisalat.ae>
'''

#Perform a latency test using TCP packets

import subprocess
import datetime
import eprobe

probeData = eprobe.read_cfg()
if not probeData == None:

    #Perform latency test towards udp_endpoints

    data_points=[]

    hping3_targets = probeData['probe-config']['hping3_endpoints']

    for target in hping3_targets:

        hping3_command = [
            'timeout', '-k', '6s',
            '5s', '/usr/sbin/hping3', '-c',
            '3', '-S', '-p',
            target['port'], target['ip']
            ] 

        flags = probeData['probe-config']['hping3_additional_flags']
        if flags[0] != " ":
            for i in flags:
                hping3_command.append(i)

        p = subprocess.Popen(hping3_command, stdout = subprocess.PIPE, stderr = subprocess.PIPE)
        out, err = p.communicate()

        hping3_results =[]

        lines = err.split('\n')
        for line in lines:
            if 'min/avg/max' in line:
                found_result = line[25:][:-3].split('/')
                if found_result[0] == '0.0' or found_result[1] == '0.0' or found_result[2] == '0.0':
                    break
                else:
                    hping3_results = found_result
                    break

        if len(hping3_results) != 0:

            payload={
                'timestamp': str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                'measurement' : 'HPING3',
                'tags' : {
                    'target_name': target['target_name'],
                    'type': target['type'].replace(' ','\ '),
                    'ip': target['ip'],
                    'port': target['port']
                    } ,
                'fields' : {
                    'RTTMin': hping3_results[0],
                    'RTTAvg': hping3_results[1],
                    'RTTMax': hping3_results[2]                    
                }
            }

            data_points.append(payload)

        else:
            print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) +' [HPING3] test run. No HPING3 result: '+str(target['target_name'])+' '+str(target['ip'])+' '+str(target['port']))

    if data_points and eprobe.send_results_to_api(data_points,probeData) == True:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [HPING3] Test results successfully sent to server")
    else:
        print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+" [HPING3] ERROR sending Test results")

else:
    print(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+' [HPING3] Error Reading probe.json')
